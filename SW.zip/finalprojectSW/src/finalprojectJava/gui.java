package finalprojectJava;

import java.awt.EventQueue;

import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLayeredPane;
import java.awt.CardLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import java.awt.Component;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.io.*;
import java.awt.Color;
import java.sql.*;

public class gui extends JFrame {

	private static final long serialVersionUID = 1L;
	// for the input
	private JPanel contentPane;
	private JPanel rpanel1;
	private JPanel rpanel2;
	private JPanel rpanel3;
	private JPanel defaultrpanel;
	private JPanel rpanel4;
	private JLayeredPane resultPane;

	// for the user's option
	private JLayeredPane layeredPane;
	private JLayeredPane inputPanel;
	private JPanel main;

	// for table
	private JTextField p1itemField;
	private JTextField p1quanField;
	private JTextField p1conField;
	private JTextField p2itemField;
	private JTextField p2quanField;
	private JTextField p2conField;
	private JTextField p3itemField;
	private JTextField p3quanField;
	private JTextField p3conField;

	private JPanel maininput;
	private JPanel bookinput;
	private JPanel shoeinput;
	private JPanel deskinput;
	private JPanel wardinput;

	private JTable rtable1;
	private JTable rtable2;
	private JTable rtable3;
	private JTable rtable4;

	// model
	DefaultTableModel model1;
	DefaultTableModel model2;
	DefaultTableModel model3;
	DefaultTableModel model4;

	private JTextField p4itemField;
	private JTextField p4quanField;
	private JTextField p4conField;

	Connection conn = null;
	PreparedStatement pstmt = null;
	private String databasePath = "project.db";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gui frame = new gui();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void changeinputPanel(JPanel panel) {
		inputPanel.removeAll();
		inputPanel.add(panel);
		inputPanel.repaint();
		inputPanel.revalidate();

	}

	public void changeresultPanel(JPanel panel) {
		resultPane.removeAll();
		resultPane.add(panel);
		resultPane.repaint();
		resultPane.revalidate();
	}

	public gui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 800);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(185, 176, 176));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		layeredPane = new JLayeredPane();
		layeredPane.setBackground(new Color(176, 193, 217));
		layeredPane.setBounds(10, 10, 666, 152);
		contentPane.add(layeredPane);
		layeredPane.setLayout(new CardLayout(0, 0));

		main = new JPanel();
		main.setBackground(new Color(176, 193, 217));
		layeredPane.add(main, "name_27537754276600");
		main.setLayout(null);

		JButton bookopt = new JButton("Book Shelf");
		bookopt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// changePanelOpt(room1);
				changeinputPanel(bookinput);
				changeresultPanel(rpanel1);

			}
		});
		bookopt.setBounds(38, 77, 85, 45);
		main.add(bookopt);

		JButton shoeopt = new JButton("Shoe Rack");
		shoeopt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// changePanelOpt(room2);
				changeinputPanel(shoeinput);
				changeresultPanel(rpanel2);
			}
		});
		shoeopt.setBounds(205, 77, 85, 45);
		main.add(shoeopt);

		JButton deskopt = new JButton("Desk Shelf");
		deskopt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// changePanelOpt(kitchen);
				changeinputPanel(deskinput);
				changeresultPanel(rpanel3);
			}
		});
		deskopt.setBounds(374, 77, 85, 45);
		main.add(deskopt);

		JButton Storeopt = new JButton("Wardrobe");
		Storeopt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				changeinputPanel(wardinput);
				changeresultPanel(rpanel4);
			}
		});
		Storeopt.setBounds(543, 77, 85, 45);
		main.add(Storeopt);

		JLabel lblNewLabel_3 = new JLabel("Stuff Manager");
		lblNewLabel_3.setFont(new Font("Lucida Fax", Font.BOLD, 14));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(254, 10, 163, 57);
		main.add(lblNewLabel_3);

		resultPane = new JLayeredPane();
		resultPane.setBounds(10, 314, 666, 439);
		contentPane.add(resultPane);
		resultPane.setLayout(new CardLayout(0, 0));

		defaultrpanel = new JPanel();
		resultPane.add(defaultrpanel, "name_4869444350300");

		// --------------------------------------------------------------------------------------------------------------------------------------------//
		// resultpanel1

		rpanel1 = new JPanel();
		resultPane.add(rpanel1, "name_25801360218500");
		rpanel1.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(38, 0, 452, 439);
		rpanel1.add(scrollPane);

		// to get table header
		rtable1 = new JTable();
		rtable1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = rtable1.getSelectedRow();
				p1itemField.setText(model1.getValueAt(i, 0).toString());
				p1quanField.setText(model1.getValueAt(i, 1).toString());
				p1conField.setText(model1.getValueAt(i, 2).toString());

			}
		});
		model1 = new DefaultTableModel();
		Object[] column1 = { "Book Name", "Pages", "Condition" };
		final Object[] row1 = new Object[3]; // because we only have 3 description for each item
		model1.setColumnIdentifiers(column1);
		rtable1.setModel(model1);
		scrollPane.setViewportView(rtable1);

		// Add
		JButton btnNewButton_4 = new JButton("Add");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (p1itemField.equals(null) || p1itemField.equals(null) || p1itemField.equals(null)) {
					JOptionPane.showMessageDialog(null, "No value. Please put any input", "Message",
							JOptionPane.ERROR_MESSAGE);
				} else {

				}
				model1.addRow(row1);
				// reset back
				p1itemField.setText("");
				p1quanField.setText("");
				p1conField.setText("");

			}
		});
		btnNewButton_4.setBounds(541, 90, 85, 21);
		rpanel1.add(btnNewButton_4);

		JButton btnNewButton_1_1 = new JButton("Update");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = rtable1.getSelectedRow();

				// set value
				if (i >= 0) {
					model1.setValueAt(p1itemField.getText(), i, 0);
					model1.setValueAt(p1quanField.getText(), i, 1);
					model1.setValueAt(p1conField.getText(), i, 2);

				} else {
					JOptionPane.showMessageDialog(null, "Please select a row first!", "Error",
							JOptionPane.ERROR_MESSAGE);

				}

			}
		});
		btnNewButton_1_1.setBounds(541, 150, 85, 21);
		rpanel1.add(btnNewButton_1_1);

		JButton btnNewButton_2_1 = new JButton("Delete");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				int i = rtable1.getSelectedRow(); // you need to click the row first then delete, otherwise it will
													// return -1
				if (i >= 0) {
					model1.removeRow(i);
				}
			}
		});
		btnNewButton_2_1.setBounds(541, 210, 85, 21);
		rpanel1.add(btnNewButton_2_1);

		JButton btnNewButton_3_1 = new JButton("Clear");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int temp = rtable1.getRowCount();
				System.out.println(temp);

				System.out.println(rtable1.getRowCount());
				// clear all table
				if (temp > 0) {
					for (int i = 0; i < temp; i++) {
						model1.removeRow(temp - i - 1);
					}
				} else {
					JOptionPane.showMessageDialog(null, "No data", "Message", JOptionPane.ERROR_MESSAGE);

				}

			}
		});
		btnNewButton_3_1.setBounds(541, 270, 85, 21);
		rpanel1.add(btnNewButton_3_1);

		JLabel lblNewLabel = new JLabel("Book Shelf");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(541, 37, 85, 32);
		rpanel1.add(lblNewLabel);

		JButton btnExport_1 = new JButton("Export");
		btnExport_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String url = "jdbc:sqlite:zem.db";
				String createTableSQL = "CREATE TABLE IF NOT EXISTS bookshelf (" + "bookname TEXT PRIMARY KEY, "
						+ "pages TEXT, " + "condition TEXT" + ");";

				// connection to database
				try (Connection conn = DriverManager.getConnection(url)) {
					if (conn != null) {
//						System.out.println("yeay");

						// create the database. if exist, then no need to create again.
						try (Statement stmt = conn.createStatement()) {
							stmt.execute(createTableSQL);
						} catch (SQLException ex) {
							System.out.println(ex);
						}

						// checking if the table havea data or not
						if (rtable1.getRowCount() == 0) {
							// If JTable is empty, delete all data from the database
							String deleteSQL = "DELETE FROM bookshelf";
							try (PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {
								pstmt.executeUpdate();
								System.out.println("All data has been deleted from the database.");
							} catch (SQLException ex) {
								System.out.println("Error deleting data: " + ex);
							}
						} else {
							// Insert or replace data into the table
							String insertSQL = "INSERT OR REPLACE INTO bookshelf (bookname, pages, condition) VALUES (?, ?, ?)";
							try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
								for (int i = 0; i < rtable1.getRowCount(); i++) {
									for (int j = 0; j < rtable1.getColumnCount(); j++) {
										pstmt.setObject(j + 1, rtable1.getValueAt(i, j));
									}
									pstmt.addBatch();
								}
								pstmt.executeBatch();
								System.out.println("Data inserted/replaced successfully.");
							} catch (SQLException y) {
								y.printStackTrace();
							}
						}

						
//						
					}

				} catch (SQLException ex) {
					System.out.println("error to connect database");
				}

			}
		});
		btnExport_1.setBounds(541, 330, 85, 21);
		rpanel1.add(btnExport_1);


		// result panel 2

		rpanel2 = new JPanel();
		resultPane.add(rpanel2, "name_25803871454500");
		rpanel2.setLayout(null);

		JButton btnNewButton_1_1_1 = new JButton("Update");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int i = rtable2.getSelectedRow();

				// set value
				if (i >= 0) {
					model2.setValueAt(p2itemField.getText(), i, 0);
					model2.setValueAt(p2quanField.getText(), i, 1);
					model2.setValueAt(p2conField.getText(), i, 2);

				} else {
					JOptionPane.showMessageDialog(null, "Please select a row first!", "Error",
							JOptionPane.ERROR_MESSAGE);

				}

			}
		});
		btnNewButton_1_1_1.setBounds(541, 150, 85, 21);
		rpanel2.add(btnNewButton_1_1_1);

		JButton btnNewButton_2_1_1 = new JButton("Delete");
		btnNewButton_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = rtable2.getSelectedRow();
				// you need to click the row first then delete, otherwise it will return -1
				if (i >= 0) {
					model2.removeRow(i);
				}
				// set value

			}
		});
		btnNewButton_2_1_1.setBounds(541, 210, 85, 21);
		rpanel2.add(btnNewButton_2_1_1);

		JButton btnNewButton_3_1_1 = new JButton("Clear");
		btnNewButton_3_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int temp = rtable2.getRowCount();
				System.out.println(temp);

				System.out.println(rtable2.getRowCount());
				// clear all table
				if (temp > 0) {
					for (int i = 0; i < temp; i++) {
						model2.removeRow(temp - i - 1);
					}
				} else {
					JOptionPane.showMessageDialog(null, "No data", "Message", JOptionPane.ERROR_MESSAGE);

				}

			}
		});
		btnNewButton_3_1_1.setBounds(541, 270, 85, 21);
		rpanel2.add(btnNewButton_3_1_1);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(38, 0, 452, 439);
		rpanel2.add(scrollPane_1);

		rtable2 = new JTable();
		rtable2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = rtable2.getSelectedRow();
				p2itemField.setText(model2.getValueAt(i, 0).toString());
				p2quanField.setText(model2.getValueAt(i, 1).toString());
				p2conField.setText(model2.getValueAt(i, 2).toString());

			}
		});

		model2 = new DefaultTableModel();
		Object[] column2 = { "Shoe", "Brand", "Condition" };
		final Object[] row2 = new Object[3]; // we only have 3 object
		model2.setColumnIdentifiers(column2);
		rtable2.setModel(model2);
		scrollPane_1.setViewportView(rtable2);

		JButton btnNewButton_4_3 = new JButton("Add");
		btnNewButton_4_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (p3itemField.equals(null) || p1itemField.equals(null) || p1itemField.equals(null)) {
					JOptionPane.showMessageDialog(null, "No value. Please put any input", "Message",
							JOptionPane.ERROR_MESSAGE);
				} else {

					model2.addRow(row2);
					// reset back
					p3itemField.setText("");
					p2quanField.setText("");
					p2conField.setText("");
					row2[0] = "";
					row2[1] = "";
					row2[2] = "";

				}

			}
		});
		btnNewButton_4_3.setBounds(541, 90, 85, 21);
		rpanel2.add(btnNewButton_4_3);

		JLabel lblNewLabel_1 = new JLabel("Shoe Rack");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(541, 37, 85, 32);
		rpanel2.add(lblNewLabel_1);

		JButton btnExport_2 = new JButton("Export");
		btnExport_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String url = "jdbc:sqlite:zem.db";
				String createTableSQL = "CREATE TABLE IF NOT EXISTS shoerack (" + "shoe TEXT PRIMARY KEY, "
						+ "brand TEXT, " + "condition TEXT" + ");";

				// connection to database
				try (Connection conn = DriverManager.getConnection(url)) {
					if (conn != null) {
//						System.out.println("yeay");

						// create the database. if exist, then no need to create again.
						try (Statement stmt = conn.createStatement()) {
							stmt.execute(createTableSQL);
						} catch (SQLException ex) {
							System.out.println(ex);
						}

						// checking if the table havea data or not
						if (rtable2.getRowCount() == 0) {
							// If JTable is empty, delete all data from the database
							String deleteSQL = "DELETE FROM shoerack";
							try (PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {
								pstmt.executeUpdate();
								System.out.println("All data has been deleted from the database.");
							} catch (SQLException ex) {
								System.out.println("Error deleting data: " + ex);
							}
						} else {
							// Insert or replace data into the table
							String insertSQL = "INSERT OR REPLACE INTO shoerack (shoe, brand, condition) VALUES (?, ?, ?)";
							try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
								for (int i = 0; i < rtable2.getRowCount(); i++) {
									for (int j = 0; j < rtable2.getColumnCount(); j++) {
										pstmt.setObject(j + 1, rtable2.getValueAt(i, j));
									}
									pstmt.addBatch();
								}
								pstmt.executeBatch();
								System.out.println("Data inserted/replaced successfully.");
							} catch (SQLException y) {
								y.printStackTrace();
							}
						}

//						
					}

				} catch (SQLException ex) {
					System.out.println("error to connect database");
				}

			}
		});
		btnExport_2.setBounds(541, 330, 85, 21);
		rpanel2.add(btnExport_2);

		// PANEL 3
		// PANEL 3
		// PANEL 3
		rpanel3 = new JPanel();
		resultPane.add(rpanel3, "name_25805525583900");
		rpanel3.setLayout(null);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(38, 0, 452, 439);
		rpanel3.add(scrollPane_2);

		rtable3 = new JTable();

		model3 = new DefaultTableModel();
		Object[] column3 = { "Item Name", "Quantity", "Condition" };
		final Object[] row3 = new Object[3]; // because we only have 3 description for each item
		model3.setColumnIdentifiers(column3);
		rtable3.setModel(model3);
		scrollPane_2.setViewportView(rtable3);

		// ADD

		JButton btnNewButton_4_3_1 = new JButton("Add");
		btnNewButton_4_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (p3itemField.equals(null) || p3itemField.equals(null) || p3itemField.equals(null)) {
					JOptionPane.showMessageDialog(null, "No value. Please put any input", "Message",
							JOptionPane.ERROR_MESSAGE);
				} else {
					model3.addRow(row3);
					// reset back
					p3itemField.setText("");
					p3quanField.setText("");
					p3conField.setText("");
				}

			}
		});
		btnNewButton_4_3_1.setBounds(541, 90, 85, 21);
		rpanel3.add(btnNewButton_4_3_1);

		JButton btnNewButton_1_1_2 = new JButton("Update");
		btnNewButton_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = rtable3.getSelectedRow();

				// set value
				if (i >= 0) {
					model3.setValueAt(p3itemField.getText(), i, 0);
					model3.setValueAt(p3quanField.getText(), i, 1);
					model3.setValueAt(p3conField.getText(), i, 2);

				} else {
					JOptionPane.showMessageDialog(null, "Please select a row first!", "Error",
							JOptionPane.ERROR_MESSAGE);

				}
			}
		});

		btnNewButton_1_1_2.setBounds(541, 150, 85, 21);
		rpanel3.add(btnNewButton_1_1_2);

		JButton btnNewButton_2_1_2 = new JButton("Delete");
		btnNewButton_2_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = rtable3.getSelectedRow(); // you need to click the row first then delete, otherwise it will
													// return -1
				if (i >= 0) {
					model3.removeRow(i);
				}
			}
		});
		btnNewButton_2_1_2.setBounds(541, 210, 85, 21);
		rpanel3.add(btnNewButton_2_1_2);

		JButton btnNewButton_3_1_2 = new JButton("Clear");
		btnNewButton_3_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int temp = rtable3.getRowCount();
				System.out.println(temp);

				System.out.println(rtable3.getRowCount());
				// clear all table
				if (temp > 0) {
					for (int i = 0; i < temp; i++) {
						model3.removeRow(temp - i - 1);
					}
				} else {
					JOptionPane.showMessageDialog(null, "No data", "Message", JOptionPane.ERROR_MESSAGE);

				}
			}
		});
		btnNewButton_3_1_2.setBounds(541, 270, 85, 21);
		rpanel3.add(btnNewButton_3_1_2);

		JButton btnExport_3 = new JButton("Export");
		btnExport_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String url = "jdbc:sqlite:zem.db";
				String createTableSQL = "CREATE TABLE IF NOT EXISTS deskshelf (" + "itemname TEXT PRIMARY KEY, "
						+ "quantity TEXT, " + "condition TEXT" + ");";

				// connection to database
				try (Connection conn = DriverManager.getConnection(url)) {
					if (conn != null) {
//						System.out.println("yeay");

						// create the database. if exist, then no need to create again.
						try (Statement stmt = conn.createStatement()) {
							stmt.execute(createTableSQL);
						} catch (SQLException ex) {
							System.out.println(ex);
						}

						// checking if the table havea data or not
						if (rtable3.getRowCount() == 0) {
							// If JTable is empty, delete all data from the database
							String deleteSQL = "DELETE FROM deskshelf";
							try (PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {
								pstmt.executeUpdate();
								System.out.println("All data has been deleted from the database.");
							} catch (SQLException ex) {
								System.out.println("Error deleting data: " + ex);
							}
						} else {
							// Insert or replace data into the table
							String insertSQL = "INSERT OR REPLACE INTO deskshelf (itemname, quantity, condition) VALUES (?, ?, ?)";
							try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
								for (int i = 0; i < rtable3.getRowCount(); i++) {
									for (int j = 0; j < rtable3.getColumnCount(); j++) {
										pstmt.setObject(j + 1, rtable3.getValueAt(i, j));
									}
									pstmt.addBatch();
								}
								pstmt.executeBatch();
								System.out.println("Data inserted/replaced successfully.");
							} catch (SQLException y) {
								y.printStackTrace();
							}
						}

//						
					}

				} catch (SQLException ex) {
					System.out.println("error to connect database");
				}

			}
		});
		btnExport_3.setBounds(541, 330, 85, 21);
		rpanel3.add(btnExport_3);

		JLabel lblNewLabel_2 = new JLabel("Desk Shelf");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(541, 37, 85, 32);
		rpanel3.add(lblNewLabel_2);

		rpanel4 = new JPanel();
		resultPane.add(rpanel4, "name_49875161259000");
		rpanel4.setLayout(null);

		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(38, 0, 452, 439);
		rpanel4.add(scrollPane_3);

		rtable4 = new JTable();
		rtable4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = rtable4.getSelectedRow();
				// get string
			}
		});
		model4 = new DefaultTableModel();
		Object[] column4 = { "Clothes", "Size", "Condition" };
		final Object[] row4 = new Object[3];
		model4.setColumnIdentifiers(column4);
		rtable4.setModel(model4);
		scrollPane_3.setViewportView(rtable4);

		JLabel lblStore = new JLabel("Wardrobe");
		lblStore.setHorizontalAlignment(SwingConstants.CENTER);
		lblStore.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblStore.setBounds(541, 37, 85, 32);
		rpanel4.add(lblStore);

		JButton btnNewButton_4_4_1 = new JButton("Add");
		btnNewButton_4_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (p4itemField.equals(null) || p4itemField.equals(null) || p4itemField.equals(null)) {
					JOptionPane.showMessageDialog(null, "No value. Please put any input", "Message",
							JOptionPane.ERROR_MESSAGE);
				} else {

				}
				model4.addRow(row4);
				// reset back
				p4itemField.setText("");
				p4quanField.setText("");
				p4conField.setText("");
			}
		});
		btnNewButton_4_4_1.setBounds(541, 90, 85, 21);
		rpanel4.add(btnNewButton_4_4_1);

		JButton btnNewButton_1_1_2_1 = new JButton("Update");
		btnNewButton_1_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = rtable4.getSelectedRow();

				// set value
				if (i >= 0) {
					model4.setValueAt(p4itemField.getText(), i, 0);
					model4.setValueAt(p4quanField.getText(), i, 1);
					model4.setValueAt(p4conField.getText(), i, 2);

				} else {
					JOptionPane.showMessageDialog(null, "Please select a row first!", "Error",
							JOptionPane.ERROR_MESSAGE);

				}
			}
		});
		btnNewButton_1_1_2_1.setBounds(541, 150, 85, 21);
		rpanel4.add(btnNewButton_1_1_2_1);

		JButton btnNewButton_2_1_2_1 = new JButton("Delete");
		btnNewButton_2_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int i = rtable4.getSelectedRow(); // you need to click the row first then delete, otherwise it will
													// return -1
				if (i >= 0) {
					model4.removeRow(i);
				}
			}
		});
		btnNewButton_2_1_2_1.setBounds(541, 210, 85, 21);
		rpanel4.add(btnNewButton_2_1_2_1);

		JButton btnNewButton_3_1_2_1 = new JButton("Clear");
		btnNewButton_3_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int temp = rtable4.getRowCount();
				System.out.println(temp);

				System.out.println(rtable4.getRowCount());
				// clear all table
				if (temp > 0) {
					for (int i = 0; i < temp; i++) {
						model4.removeRow(temp - i - 1);
					}
				} else {
					JOptionPane.showMessageDialog(null, "No data", "Message", JOptionPane.ERROR_MESSAGE);

				}
			}
		});
		btnNewButton_3_1_2_1.setBounds(541, 270, 85, 21);
		rpanel4.add(btnNewButton_3_1_2_1);

		JButton btnExport_4 = new JButton("Export");
		btnExport_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String url = "jdbc:sqlite:zem.db";
				String createTableSQL = "CREATE TABLE IF NOT EXISTS wardrobe (" + "clothes TEXT PRIMARY KEY, "
						+ "size TEXT, " + "condition TEXT" + ");";

				// connection to database
				try (Connection conn = DriverManager.getConnection(url)) {
					if (conn != null) {
//						System.out.println("yeay");

						// create the database. if exist, then no need to create again.
						try (Statement stmt = conn.createStatement()) {
							stmt.execute(createTableSQL);
						} catch (SQLException ex) {
							System.out.println(ex);
						}

						// checking if the table havea data or not
						if (rtable4.getRowCount() == 0) {
							// If JTable is empty, delete all data from the database
							String deleteSQL = "DELETE FROM wardrobe";
							try (PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {
								pstmt.executeUpdate();
								System.out.println("All data has been deleted from the database.");
							} catch (SQLException ex) {
								System.out.println("Error deleting data: " + ex);
							}
						} else {
							// Insert or replace data into the table
							String insertSQL = "INSERT OR REPLACE INTO wardrobe (clothes, size, condition) VALUES (?, ?, ?)";
							try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
								for (int i = 0; i < rtable4.getRowCount(); i++) {
									for (int j = 0; j < rtable4.getColumnCount(); j++) {
										pstmt.setObject(j + 1, rtable4.getValueAt(i, j));
									}
									pstmt.addBatch();
								}
								pstmt.executeBatch();
								System.out.println("Data inserted/replaced successfully.");
							} catch (SQLException y) {
								y.printStackTrace();
							}
						}

//						
					}

				} catch (SQLException ex) {
					System.out.println("error to connect database");
				}

			}
		});
		btnExport_4.setBounds(541, 330, 85, 21);
		rpanel4.add(btnExport_4);

		inputPanel = new JLayeredPane();
		inputPanel.setBounds(10, 182, 666, 109);
		contentPane.add(inputPanel);
		inputPanel.setLayout(new CardLayout(0, 0));

		maininput = new JPanel();
		inputPanel.add(maininput, "name_391511502900");

		bookinput = new JPanel();
		inputPanel.add(bookinput, "name_391548113100");
		bookinput.setLayout(null);

		JLabel ilabel1_1 = new JLabel("Book Name");
		ilabel1_1.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel1_1.setBounds(51, 10, 96, 13);
		bookinput.add(ilabel1_1);

		JLabel ilabel1_2 = new JLabel("Pages");
		ilabel1_2.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel1_2.setBounds(289, 10, 96, 13);
		bookinput.add(ilabel1_2);

		JLabel ilabel1_3 = new JLabel("Condition");
		ilabel1_3.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel1_3.setBounds(531, 10, 96, 13);
		bookinput.add(ilabel1_3);

		JButton p1Submit = new JButton("Submit");
		p1Submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (p1itemField.getText().equals("") || p1quanField.getText().equals("")
						|| p1conField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please fill in the blank", "Message",
							JOptionPane.ERROR_MESSAGE);
				} else {

					row1[0] = p1itemField.getText();
					row1[1] = p1quanField.getText();
					row1[2] = p1conField.getText();
				}

			}
		});
		p1Submit.setBounds(216, 78, 85, 21);
		bookinput.add(p1Submit);

		JButton p1Reset = new JButton("Reset");
		p1Reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p1itemField.setText("");
				p1quanField.setText("");
				p1conField.setText("");

			}
		});
		p1Reset.setBounds(362, 78, 85, 21);
		bookinput.add(p1Reset);

		p1itemField = new JTextField();
		p1itemField.setBounds(51, 33, 96, 19);
		bookinput.add(p1itemField);
		p1itemField.setColumns(10);

		p1quanField = new JTextField();
		p1quanField.setBounds(289, 33, 96, 19);
		bookinput.add(p1quanField);
		p1quanField.setColumns(10);

		p1conField = new JTextField();
		p1conField.setBounds(531, 33, 96, 19);
		bookinput.add(p1conField);
		p1conField.setColumns(10);

		// --------------------------------------------------------------------------------------------------------------------------------------------//
		// resultpanel2

		shoeinput = new JPanel();
		inputPanel.add(shoeinput, "name_391579504600");
		shoeinput.setLayout(null);

		JLabel ilabel2_1 = new JLabel("Shoe ");
		ilabel2_1.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel2_1.setBounds(51, 10, 96, 13);
		shoeinput.add(ilabel2_1);

		JLabel ilabel2_2 = new JLabel("Brand");
		ilabel2_2.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel2_2.setBounds(289, 10, 96, 13);
		shoeinput.add(ilabel2_2);

		JLabel ilabel2_3 = new JLabel("Condition");
		ilabel2_3.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel2_3.setBounds(531, 10, 96, 13);
		shoeinput.add(ilabel2_3);

		JButton btnSubmit_2 = new JButton("Submit");
		btnSubmit_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (p2itemField.getText().equals("") || p2quanField.getText().equals("")
						|| p2conField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please fill in the blank", "Message",
							JOptionPane.ERROR_MESSAGE);
				} else {

					row2[0] = p2itemField.getText();
					row2[1] = p2quanField.getText();
					row2[2] = p2conField.getText();

				}
			}
		});
		btnSubmit_2.setBounds(216, 78, 85, 21);
		shoeinput.add(btnSubmit_2);

		JButton btnReset_2 = new JButton("Reset");
		btnReset_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p2itemField.setText("");
				p2quanField.setText("");
				p2conField.setText("");

			}
		});
		btnReset_2.setBounds(362, 78, 85, 21);
		shoeinput.add(btnReset_2);

		p2itemField = new JTextField();
		p2itemField.setColumns(10);
		p2itemField.setBounds(51, 33, 96, 19);
		shoeinput.add(p2itemField);

		p2quanField = new JTextField();
		p2quanField.setColumns(10);
		p2quanField.setBounds(289, 33, 96, 19);
		shoeinput.add(p2quanField);

		p2conField = new JTextField();
		p2conField.setColumns(10);
		p2conField.setBounds(531, 33, 96, 19);
		shoeinput.add(p2conField);

		// panel 3

		deskinput = new JPanel();
		inputPanel.add(deskinput, "name_391608853600");
		deskinput.setLayout(null);

		JLabel ilabel3_1 = new JLabel("Item Name");
		ilabel3_1.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel3_1.setBounds(51, 10, 96, 13);
		deskinput.add(ilabel3_1);

		JLabel ilabel3_2 = new JLabel("Quantity");
		ilabel3_2.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel3_2.setBounds(289, 10, 96, 13);
		deskinput.add(ilabel3_2);

		JLabel ilabel3_3 = new JLabel("Condition");
		ilabel3_3.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel3_3.setBounds(531, 10, 96, 13);
		deskinput.add(ilabel3_3);

		JButton btnSubmit_3 = new JButton("Submit");
		btnSubmit_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (p3itemField.getText().equals("") || p3quanField.getText().equals("")
						|| p3conField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please fill in the blank", "Message",
							JOptionPane.ERROR_MESSAGE);
				} else {

					row3[0] = p3itemField.getText();
					row3[1] = p3quanField.getText();
					row3[2] = p3conField.getText();
				}

			}
		});
		btnSubmit_3.setBounds(216, 78, 85, 21);
		deskinput.add(btnSubmit_3);

		JButton btnReset_3 = new JButton("Reset");
		btnReset_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p3itemField.setText("");
				p3quanField.setText("");
				p3conField.setText("");

			}
		});
		btnReset_3.setBounds(362, 78, 85, 21);
		deskinput.add(btnReset_3);

		p3itemField = new JTextField();
		p3itemField.setColumns(10);
		p3itemField.setBounds(51, 33, 96, 19);
		deskinput.add(p3itemField);

		p3quanField = new JTextField();
		p3quanField.setColumns(10);
		p3quanField.setBounds(289, 33, 96, 19);
		deskinput.add(p3quanField);

		p3conField = new JTextField();
		p3conField.setColumns(10);
		p3conField.setBounds(531, 33, 96, 19);
		deskinput.add(p3conField);

		wardinput = new JPanel();
		inputPanel.add(wardinput, "name_391637085400");
		wardinput.setLayout(null);

		JLabel ilabel4_1 = new JLabel("Clothes");
		ilabel4_1.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel4_1.setBounds(51, 10, 96, 13);
		wardinput.add(ilabel4_1);

		JLabel ilabel4_2 = new JLabel("Size");
		ilabel4_2.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel4_2.setBounds(289, 10, 96, 13);
		wardinput.add(ilabel4_2);

		JLabel ilabel4_3 = new JLabel("Condition");
		ilabel4_3.setHorizontalAlignment(SwingConstants.CENTER);
		ilabel4_3.setBounds(531, 10, 96, 13);
		wardinput.add(ilabel4_3);

		// panel4 input
		JButton btnSubmit_4 = new JButton("Submit");
		btnSubmit_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (p4itemField.getText().equals("") || p4quanField.getText().equals("")
						|| p4conField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please fill in the blank", "Message",
							JOptionPane.ERROR_MESSAGE);
				} else {

					row4[0] = p4itemField.getText();
					row4[1] = p4quanField.getText();
					row4[2] = p4conField.getText();
				}

			}
		});
		btnSubmit_4.setBounds(216, 78, 85, 21);
		wardinput.add(btnSubmit_4);

		JButton btnReset_4 = new JButton("Reset");
		btnReset_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p4itemField.setText("");
				p4quanField.setText("");
				p4conField.setText("");

			}
		});
		btnReset_4.setBounds(362, 78, 85, 21);
		wardinput.add(btnReset_4);

		p4itemField = new JTextField();
		p4itemField.setColumns(10);
		p4itemField.setBounds(51, 33, 96, 19);
		wardinput.add(p4itemField);

		p4quanField = new JTextField();
		p4quanField.setColumns(10);
		p4quanField.setBounds(289, 33, 96, 19);
		wardinput.add(p4quanField);

		p4conField = new JTextField();
		p4conField.setColumns(10);
		p4conField.setBounds(531, 33, 96, 19);
		wardinput.add(p4conField);
	}
}
